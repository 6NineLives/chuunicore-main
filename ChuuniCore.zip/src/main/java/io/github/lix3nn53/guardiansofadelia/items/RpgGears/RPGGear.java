package io.github.lix3nn53.guardiansofadelia.items.RpgGears;

import org.bukkit.inventory.ItemStack;

public interface RPGGear {

    ItemStack getItemStack();

}
