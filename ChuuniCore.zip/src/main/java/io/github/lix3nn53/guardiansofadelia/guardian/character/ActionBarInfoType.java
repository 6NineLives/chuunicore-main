package io.github.lix3nn53.guardiansofadelia.guardian.character;

public enum ActionBarInfoType {
    PASSIVE_COOLDOWN,
    VARIABLE,
    COMPANION_COUNT
}
