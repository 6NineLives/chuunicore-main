package io.github.lix3nn53.guardiansofadelia.bungeelistener.web;

public enum WebProductType {
    ITEM,
    RANK
}
