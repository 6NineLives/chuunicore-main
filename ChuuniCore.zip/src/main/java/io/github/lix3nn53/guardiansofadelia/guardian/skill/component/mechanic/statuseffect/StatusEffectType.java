package io.github.lix3nn53.guardiansofadelia.guardian.skill.component.mechanic.statuseffect;

public enum StatusEffectType {
    STUN,
    SILENCE,
    DISARM,
    ROOT
}
