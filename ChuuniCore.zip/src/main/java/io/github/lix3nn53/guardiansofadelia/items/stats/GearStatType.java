package io.github.lix3nn53.guardiansofadelia.items.stats;

public enum GearStatType {
    WEAPON_GEAR,
    ARMOR_GEAR,
    PASSIVE_GEAR
}
