package io.github.lix3nn53.guardiansofadelia.events;

import org.bukkit.event.Listener;

public class MyMythicMobSpawnEvent implements Listener {

    /*@EventHandler(priority = EventPriority.NORMAL, ignoreCancelled = true)
    public void onEvent(MythicMobSpawnEvent e) {

    }*/

}
