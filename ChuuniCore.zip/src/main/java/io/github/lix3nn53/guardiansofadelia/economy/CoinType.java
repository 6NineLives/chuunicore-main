package io.github.lix3nn53.guardiansofadelia.economy;

public enum CoinType {
    COPPER,
    SILVER,
    GOLD
}
