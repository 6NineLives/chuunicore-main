package io.github.lix3nn53.guardiansofadelia.events;

import org.bukkit.event.Listener;

public class MyEntityDismountEvent implements Listener {

    /*
    @EventHandler(priority = EventPriority.NORMAL, ignoreCancelled = true)
    public void onEvent(EntityDismountEvent e) {
        Entity entity = e.getEntity();
        if (entity instanceof LivingEntity) {
            LivingEntity livingEntity = (LivingEntity) entity;
            PetManager.onDismount(livingEntity);
        }
    }

     */
}
