package io.github.lix3nn53.guardiansofadelia.menu.merchant.storage;

import io.github.lix3nn53.guardiansofadelia.utilities.gui.GuiGeneric;

public class GuiPersonalStorage extends GuiGeneric {

    public GuiPersonalStorage() {
        super(54, "Personal Storage", 0);

        setLocked(false);
    }
}
