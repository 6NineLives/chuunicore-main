package io.github.lix3nn53.guardiansofadelia.items.stats;

public interface Stat {


}
