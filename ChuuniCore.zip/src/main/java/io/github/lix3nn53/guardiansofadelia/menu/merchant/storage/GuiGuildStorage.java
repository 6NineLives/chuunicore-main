package io.github.lix3nn53.guardiansofadelia.menu.merchant.storage;

import io.github.lix3nn53.guardiansofadelia.utilities.gui.GuiGeneric;

public class GuiGuildStorage extends GuiGeneric {

    public GuiGuildStorage() {
        super(54, "Guild Storage", 0);

        setLocked(false);
    }
}
