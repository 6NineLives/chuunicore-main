package io.github.lix3nn53.guardiansofadelia.guardian.skill.component.mechanic.projectile;

public enum SpreadType {
    CONE,
    HORIZONTAL_CONE,
    RAIN

}
