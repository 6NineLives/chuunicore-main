package io.github.lix3nn53.guardiansofadelia.creatures.custom;

//import net.minecraft.world.entity.EntityTypes;
//import net.minecraft.world.entity.projectile.EntityShulkerBullet;
//import net.minecraft.world.level.World;
//
//public class CustomShulkerBullet extends EntityShulkerBullet {

//    public CustomShulkerBullet(EntityTypes<? extends EntityShulkerBullet> entitytypes, World world) {
//        super(entitytypes, world);
//    }
//
//
//}
