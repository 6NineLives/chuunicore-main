package io.github.lix3nn53.guardiansofadelia.text.font;

import net.md_5.bungee.api.ChatColor;

public final class CustomCharacterAvatar {

    public static final CustomCharacter GENERIC = new CustomCharacter("AVATAR_GENERIC", '섆', 2, 41, ChatColor.WHITE, NegativeSpace.NEGATIVE_4, NegativeSpace.POSITIVE_4);

}
