package io.github.lix3nn53.guardiansofadelia.guardian.skill.component;

public abstract class ConditionComponent extends SkillComponent {

    public ConditionComponent(boolean addLore) {
        super(addLore);
    }
}
